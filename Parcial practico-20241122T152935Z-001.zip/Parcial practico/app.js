
function verificarEquipos() {
    
    let edad = document.getElementById('edad').value;
    let peso = document.getElementById('peso').value;
    let estatura = document.getElementById('estatura').value;
    let lentes = document.getElementById('lentes').checked;

    
    edad = Number(edad);
    peso = Number(peso);
    estatura = Number(estatura);
  let resultado = "Puede participar en: ";
    let puedeParticipar = false;

    if (edad >= 15 && edad <= 18 && peso >= 64 && peso < 70 && estatura >= 165 && !lentes) {
        resultado += "Fútbol, ";
        puedeParticipar = true;
    }

     if (edad >= 16 && edad <= 19 && peso >= 60 && peso <= 70 && estatura > 170) {
        resultado += "Béisbol, ";
        puedeParticipar = true;
    }
if (edad >= 14 && edad <= 20 && peso >= 50 && peso <= 80 && estatura >= 160) {
        resultado += "Atletismo, ";
        puedeParticipar = true;
    }

     resultado = resultado.slice(0, -2);

    
    if (!puedeParticipar) {
        resultado = " No cumples con los requisitos para ningún equipo.";
    }

    document.getElementById('resultado').textContent = resultado;
}
